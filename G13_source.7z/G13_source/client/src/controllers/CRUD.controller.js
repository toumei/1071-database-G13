export const handleChangeTable = (bind, table) => {
  bind.setState({ table: table });
};
