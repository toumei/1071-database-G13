export default {
  login: "/login",
  signup: "/signup",
  account: "/account",
  role: "/role",
  account_role: "/account_role",
  boarder: "/boarder",

  databse: "/database"
};
